
const MainBG = () => {

    return <article className="main-article">
                <div className="main-bg">
                    <h1>My Portofolio Site</h1>
                    <h2>A free, responsive, one page Bootstrap theme created by Start Bootstrap.</h2>
                    <a href="/about">ABOUT ME</a>
                </div>
            </article>
}

export default MainBG;