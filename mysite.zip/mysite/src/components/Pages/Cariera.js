import Header from "../Header/Header";


export default function Cariera () {

    return (<>
        <Header/>
    </>)
}