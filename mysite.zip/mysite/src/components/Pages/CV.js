import Header from "../Header/Header";


export default function CV () {

    return (<>
        <Header/>
        <h2>CV</h2>
    </>)
}