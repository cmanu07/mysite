import Header from "../Header/Header";
import Counter from "../Main/Counter";

export default function Proiecte () {

    return (<>
        <Header/>
        <h2>Proiecte</h2>
        <Counter/>
    </>)
}