import Header from "../Header/Header";


export default function Despre () {

    return (<>
        <Header/>
        <h2>Despre</h2>
    </>)
}